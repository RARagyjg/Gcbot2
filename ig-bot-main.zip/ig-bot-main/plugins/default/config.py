# weather.py
api_key = "your_api_key" # from openweathermap.org; make an account to get a free api key
default_city = "your_city"
