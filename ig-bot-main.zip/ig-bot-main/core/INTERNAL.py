ON_HELP = 'on_help'
ON_EVERYONE = 'on_everyone'

_DEACTIVATE = '_deactivate'
_QUIT = '_quit'
_RUN = '_run'

HUMANIZATION_DELAY = 0.1

WEBDRIVER_FIREFOX = "firefox"
WEBDRIVER_CHROME = "chrome"

USER_AGENT_CHROME = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
