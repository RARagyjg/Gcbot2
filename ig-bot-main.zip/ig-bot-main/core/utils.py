from config import command_prefix

def commandify(command_body):
    return command_prefix + str(command_body)
