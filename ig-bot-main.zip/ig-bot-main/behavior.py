from core.command_factory import override_default
from core.default_behavior import command_help_key

# your custom overrides for builtin commands here
